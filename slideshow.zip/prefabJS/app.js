var prefabLOG = require('./prefabLOG')({module: 'app'});

console.log("in app");